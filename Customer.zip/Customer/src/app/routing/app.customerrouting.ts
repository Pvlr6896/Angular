import { AppComponent } from "../customer/app.component";


export const CustomerRoutes=[

{ path :'Add', component: AppComponent},
];
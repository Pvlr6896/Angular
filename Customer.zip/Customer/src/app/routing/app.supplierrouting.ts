

import { SupplierComponent } from "../supplier/app.supplier";

export const SupplierRoutes=[

{ path :'Adding', component: SupplierComponent },
];

import { HomeComponent } from "../home/app.homepage";


export const MainRoutes=[
{ path :'Home', component :HomeComponent},
{ path :'Customer', loadChildren:'../customer/app.customermodule#AppModule'},
{ path :'Supplier', loadChildren:'../supplier/app.suppliermodule#SupplierModule'},

];
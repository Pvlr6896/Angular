import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule} from "@angular/forms"; 
import { RouterModule} from "@angular/router"
import { AppRoutingModule } from '../app-routing.module';
import { HomeComponent } from '../home/app.homepage';
import { MasterPageComponent } from '../home/app.masterpage';
import { MainRoutes} from '../routing/app.mainrouting';

@NgModule({
  declarations: [
    HomeComponent,MasterPageComponent
  ],
  imports: [
    
    RouterModule.forRoot(MainRoutes),
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [MasterPageComponent]
})
export class AppModule {

 }

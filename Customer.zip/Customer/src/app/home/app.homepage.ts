import { Component } from '@angular/core';


@Component({
 
  templateUrl: './app.homepage.html'
})
export class HomeComponent {
  
}

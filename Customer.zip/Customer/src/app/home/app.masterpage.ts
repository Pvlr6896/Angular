import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.masterpage.html'
})
export class MasterPageComponent {
  
}

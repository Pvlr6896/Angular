import { Component } from '@angular/core';


@Component({
  templateUrl: './app.supplier.html'
})
export class SupplierComponent {
  
}

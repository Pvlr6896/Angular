import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule} from "@angular/forms"; 
import { RouterModule} from "@angular/router"
import { AppRoutingModule } from '../app-routing.module';
import { SupplierComponent } from '../supplier/app.supplier';
import { SupplierRoutes} from '../routing/app.supplierrouting';
@NgModule({
  declarations: [
  SupplierComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forChild(SupplierRoutes)
  ],
  providers: [],
  bootstrap: [SupplierComponent]
})
export class AppModule {

 }

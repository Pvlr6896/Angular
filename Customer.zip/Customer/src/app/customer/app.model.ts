export class Customer{
    CustomerCode: string="";
    CustomerName:string="";
    CustomerAmount:number=0;

}
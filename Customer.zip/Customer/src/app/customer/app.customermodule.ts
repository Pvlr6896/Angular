import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule} from "@angular/forms"; 
import { RouterModule} from "@angular/router"
import { AppRoutingModule } from '../app-routing.module';
import { AppComponent } from '../customer/app.component';
import { CustomerRoutes} from '../routing/app.customerrouting';
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    NgModule,
    CommonModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forChild(CustomerRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

 }
